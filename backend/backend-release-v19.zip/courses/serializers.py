from django.contrib.auth import get_user_model
from rest_framework import serializers
from .models import Course, Module, VideoLesson, TranslatedAudio, LessonProgress, LiveClass, LiveBatch, LiveBatchStudent, CourseInstructor, Assessment, Question, QuestionOption, AssessmentAttempt, AssessmentAnswerOptionSnapshot, Certificate, CertificateTemplate, Assignment, AssignmentSubmission
from .languages import get_language_name

User = get_user_model()


class CourseInstructorSerializer(serializers.ModelSerializer):
    """
    Course "who is responsible for it" -- completely separate from
    Enrollment ("who has access to learn it"). See CourseInstructor model.
    """
    user_name = serializers.SerializerMethodField()
    user_email = serializers.EmailField(source='user.email', read_only=True)
    user_phone = serializers.CharField(source='user.phone_number', read_only=True)
    is_active_user = serializers.BooleanField(source='user.is_active', read_only=True)

    class Meta:
        model = CourseInstructor
        fields = (
            'id', 'course', 'user', 'user_name', 'user_email', 'user_phone',
            'is_active_user', 'role', 'is_primary', 'created_at'
        )
        read_only_fields = ('id', 'created_at')

    def get_user_name(self, obj):
        name = f"{obj.user.first_name} {obj.user.last_name}".strip()
        return name or obj.user.username

    def validate(self, attrs):
        user = attrs.get('user') or getattr(self.instance, 'user', None)
        course = attrs.get('course') or getattr(self.instance, 'course', None)
        role = attrs.get('role') or getattr(self.instance, 'role', CourseInstructor.InstructorRole.TEACHER)

        if user is not None:
            is_eligible = (
                getattr(user, 'is_teacher', False)
                or getattr(user, 'is_mentor', False)
                or user.is_staff
                or user.is_superuser
            )
            if not is_eligible:
                raise serializers.ValidationError(
                    {"user": "Only teacher, mentor, or admin accounts can be assigned as a course instructor."}
                )

        if user is not None and course is not None:
            qs = CourseInstructor.objects.filter(course=course, user=user, role=role)
            if self.instance:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise serializers.ValidationError(
                    "This user already has this role on this course."
                )

        return attrs

class TranslatedAudioSerializer(serializers.ModelSerializer):
    class Meta:
        model = TranslatedAudio
        fields = ['id', 'lesson', 'language_code', 'language_name', 'audio_file', 'status', 'created_at', 'updated_at']
        read_only_fields = ['id', 'lesson', 'status', 'created_at', 'updated_at']


class TranslatedAudioUploadSerializer(serializers.Serializer):
    """
    Input validation for the manual audio-upload endpoint
    (VideoLessonViewSet.upload_audio). Deliberately separate from
    TranslatedAudioSerializer, which represents the stored/output shape.
    """
    language_code = serializers.CharField(max_length=10, allow_blank=False)
    language_name = serializers.CharField(max_length=100, required=False, allow_blank=True)
    audio_file = serializers.FileField()

    def validate_language_code(self, value):
        code = value.strip()
        if not code:
            raise serializers.ValidationError("language_code is required.")
        if code.lower() == 'en':
            raise serializers.ValidationError(
                "English is the original lesson audio and cannot be uploaded as a translated track."
            )
        return code

    def validate_audio_file(self, value):
        allowed_extensions = ('.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac')
        name = (value.name or '').lower()
        if not name.endswith(allowed_extensions):
            raise serializers.ValidationError(
                f"Unsupported audio file type. Allowed: {', '.join(allowed_extensions)}"
            )
        return value

    def validate(self, attrs):
        if not attrs.get('language_name'):
            attrs['language_name'] = get_language_name(attrs['language_code'])
        else:
            attrs['language_name'] = attrs['language_name'].strip()
        return attrs

class VideoLessonSerializer(serializers.ModelSerializer):
    translated_audios = TranslatedAudioSerializer(many=True, read_only=True)

    class Meta:
        model = VideoLesson
        fields = ['id', 'title', 'description', 'transcript', 'timed_transcript', 'video_file', 'order', 'module', 'translated_audios']

    def to_internal_value(self, data):
        # Support direct S3 presigned upload where video_file is already uploaded to S3 as a key string
        if isinstance(data, dict) and 'video_file' in data and isinstance(data['video_file'], str):
            video_file_str = data['video_file']
            data = data.copy()
            data.pop('video_file')
            ret = super().to_internal_value(data)
            ret['video_file'] = video_file_str
            return ret
        return super().to_internal_value(data)

def _serialize_assessment_summary_for_student(assessment, attempts):
    """
    Phase 4.3. Safe assessment summary for the module learning-discovery
    list -- title/question_count/time_limit/passing_percentage plus this
    ONE student's own status, derived only from `attempts` (already
    scoped to `student=request.user` by the caller, one query total for
    the whole request -- see CourseViewSet.get_serializer_context). Never
    touches Question/QuestionOption, so there is nothing here that could
    leak is_correct even by accident.

    Status is read-only/display-only: an IN_PROGRESS attempt whose time
    limit has technically elapsed is still shown as IN_PROGRESS here
    (this is a plain GET on a shared course-detail endpoint, so it never
    writes anything) -- the authoritative expiry check and status flip to
    TIMED_OUT happens exactly once, when the student actually opens
    GET .../assessment-attempts/<id>/ (see _expire_if_overdue in
    courses/views.py), the only source of truth for "is this attempt
    still actually active."
    """
    active = next((a for a in attempts if a.status == AssessmentAttempt.Status.IN_PROGRESS), None)
    passed_attempt = next((a for a in attempts if a.status == AssessmentAttempt.Status.SUBMITTED and a.passed), None)
    attempts_used = len(attempts)

    if active is not None:
        student_status = "IN_PROGRESS"
        cta_attempt_id = active.id
    elif passed_attempt is not None:
        student_status = "PASSED"
        cta_attempt_id = passed_attempt.id
    elif attempts_used >= assessment.max_attempts:
        student_status = "MAX_ATTEMPTS_REACHED"
        cta_attempt_id = attempts[0].id if attempts else None  # most recent -- default ordering is -started_at
    elif attempts_used > 0:
        student_status = "FAILED"
        cta_attempt_id = None
    else:
        student_status = "NOT_STARTED"
        cta_attempt_id = None

    return {
        "id": assessment.id,
        "title": assessment.title,
        "question_count": assessment.question_count,
        "time_limit_minutes": assessment.time_limit_minutes,
        "passing_percentage": assessment.passing_percentage,
        "max_attempts": assessment.max_attempts,
        "status": student_status,
        "attempts_used": attempts_used,
        "attempts_remaining": max(assessment.max_attempts - attempts_used, 0),
        "attempt_id": cta_attempt_id,
    }


class ModuleSerializer(serializers.ModelSerializer):
    """
    Course-content security follow-up (post-3.4.4): this is where locked
    lesson content actually gets redacted, not VideoLessonSerializer
    itself. The access decision needs a course id -- Module already has
    one directly (`course_id`, a plain FK field, zero extra queries) --
    whereas a VideoLesson only has it via `.module.course_id`, an extra
    hop that would cost one query PER LESSON unless the modules were
    prefetched specially for this. Deciding "locked or not" once per
    Module (reusing the same course_id for every lesson under it) and
    post-processing the already-serialized lesson dicts keeps this at
    zero additional queries beyond the one-time context computation in
    CourseViewSet.get_serializer_context() (see there for what populates
    `course_content_full_access_ids`/`bypass_content_lock`).
    """
    lessons = VideoLessonSerializer(many=True, read_only=True)
    assessments = serializers.SerializerMethodField()
    assignments = serializers.SerializerMethodField()

    class Meta:
        model = Module
        fields = ['id', 'title', 'order', 'lessons', 'course', 'assessments', 'assignments']

    def get_assignments(self, obj):
        """
        Phase 4.7: published assignments for this module, with per-student
        submission status -- exact same pattern as get_assessments (same
        access flag, same "never touch the DB when there's nothing to
        show", same "unpublished never appears regardless of role").
        Deliberately does NOT feed into completion.py -- assignments are
        not part of Phase 4.5 module/course completion in this phase.
        """
        if not self._has_full_content_access(obj):
            return []

        assignments = obj.assignments.filter(is_published=True).order_by('order')
        submissions_by_assignment = self.context.get('student_submissions_by_assignment_id', {})
        return [
            _serialize_assignment_summary_for_student(a, submissions_by_assignment.get(a.id, []))
            for a in assignments
        ]

    def get_assessments(self, obj):
        """
        Phase 4.3: published assessments for this module, with per-student
        status -- reuses the exact same `_has_full_content_access` flag
        this serializer already computes for lesson locking (course
        access OR instructor content-view access), so assessment
        visibility can never disagree with lesson visibility for the same
        module. Unauthenticated/no-access requests get `[]` with zero
        extra queries (the DB is never touched when there's nothing to
        show); is_published=False assessments never appear here at all,
        regardless of role -- this is the student learning view, not the
        admin authoring surface.
        """
        if not self._has_full_content_access(obj):
            return []

        from django.db.models import Count
        assessments = obj.assessments.filter(is_published=True).annotate(
            question_count=Count('questions')
        ).order_by('order')

        attempts_by_assessment = self.context.get('student_attempts_by_assessment_id', {})
        return [
            _serialize_assessment_summary_for_student(a, attempts_by_assessment.get(a.id, []))
            for a in assessments
        ]

    def _has_full_content_access(self, obj):
        if self.context.get('bypass_content_lock'):
            return True
        full_access_ids = self.context.get('course_content_full_access_ids')
        if full_access_ids is None:
            # No context populated at all -- fail CLOSED, never open. A
            # caller that forgets to populate this context should get a
            # locked response, not an accidentally-public one.
            return False
        return obj.course_id in full_access_ids

    def to_representation(self, instance):
        data = super().to_representation(instance)
        has_access = self._has_full_content_access(instance)
        completed_lesson_ids = self.context.get('completed_lesson_ids', set())
        for lesson_data in data['lessons']:
            lesson_data['is_locked'] = not has_access
            # Phase 4.5: a completion FACT about this user's own history,
            # not paid content -- shown regardless of has_access (matches
            # the existing "outline visible" half of the lock contract,
            # extended to completion state; see the Phase 4.5 report).
            lesson_data['is_completed'] = lesson_data['id'] in completed_lesson_ids
            if not has_access:
                # video_file/transcript/timed_transcript/translated_audios
                # (and each translated_audios entry's own audio_file) are
                # the only fields ever redacted -- title/description/order/
                # module stay visible, matching the approved "outline
                # visible, content locked" contract; nulling them here
                # (rather than not fetching them at all) means no
                # functional S3 URL is ever included in the response, per
                # the security requirement, without needing to change how
                # VideoLessonSerializer/TranslatedAudioSerializer fetch
                # their data.
                lesson_data['transcript'] = None
                lesson_data['timed_transcript'] = None
                lesson_data['video_file'] = None
                lesson_data['translated_audios'] = []

        # Phase 4.5: module completion, derived from the lesson/assessment
        # data already built above -- zero extra queries (see
        # courses/services/completion.py's own docstring). A locked
        # module gets None for all four fields, never a computed number --
        # assessments are already hidden ([]) when locked (Phase 4.3), so
        # computing "100%" from lessons alone here would be actively
        # wrong, not just imprecise; None means "not applicable," matching
        # this codebase's own established convention (see
        # CourseSerializer.progress_percentage's identical choice for
        # anonymous requests).
        from .services.completion import compute_module_completion, LOCKED_COMPLETION
        if has_access:
            data.update(compute_module_completion(data['lessons'], data['assessments']))
        else:
            data.update(LOCKED_COMPLETION)
        return data

class CourseSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, read_only=True)
    progress_percentage = serializers.SerializerMethodField()

    class Meta:
        model = Course
        fields = ['id', 'title', 'description', 'price', 'thumbnail', 'is_published', 'created_at', 'course_type', 'modules', 'progress_percentage']

    def get_progress_percentage(self, obj):
        """
        Phase 3.9: real, server-computed course-level completion --
        previously the student dashboard hardcoded "0% Completed" and a
        static 5% progress bar for every course, never derived from
        LessonProgress at all. Computed as
        (this user's completed VideoLessons in this course) /
        (total VideoLessons in this course), matching exactly how
        LessonProgress/VideoLessonViewSet.progress already defines
        "completed" per lesson -- never re-deriving or guessing a
        different completion rule.

        Anonymous/unauthenticated requests (e.g. the public course catalog,
        which reuses this same serializer) get None rather than 0 -- "0%"
        would misleadingly imply a real, checked position; None means
        "not applicable, no user to compute this for", which the frontend
        must not render as a percentage.
        """
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        if not user or not user.is_authenticated:
            return None

        total_lessons = VideoLesson.objects.filter(module__course=obj).count()
        if total_lessons == 0:
            return 0

        completed_lessons = LessonProgress.objects.filter(
            user=user, lesson__module__course=obj, completed=True,
        ).count()
        return round((completed_lessons / total_lessons) * 100)

    def to_representation(self, instance):
        """
        Phase 4.5: course-level completion, derived from the already-
        serialized modules above -- zero extra queries. Deliberately
        separate from `progress_percentage` (Phase 3.9, lesson-only,
        still used by the dashboard card badge and left completely
        unchanged) -- this is the module-completion-based metric Phase
        4.5 introduces, under its own field names, extending rather than
        replacing the existing one. If any module came back locked (None
        -- module-level access is course-wide, so either all of a
        course's modules are locked or none are), the course-level fields
        are None too, for the same "never fabricate a number" reason.
        """
        data = super().to_representation(instance)
        from .services.completion import compute_course_completion, LOCKED_COURSE_COMPLETION
        modules_data = data.get('modules', [])
        if modules_data and any(m.get('is_completed') is None for m in modules_data):
            data.update(LOCKED_COURSE_COMPLETION)
        else:
            data.update(compute_course_completion(modules_data))
        return data

from .models import Enrollment

class AdminEnrollmentSerializer(serializers.ModelSerializer):
    student_name = serializers.SerializerMethodField()
    student_email = serializers.EmailField(source='user.email', read_only=True)
    student_phone = serializers.CharField(source='user.phone_number', read_only=True)
    course_title = serializers.CharField(source='course.title', read_only=True)
    source = serializers.SerializerMethodField()

    class Meta:
        model = Enrollment
        fields = (
            'id',
            'student_name',
            'student_email',
            'student_phone',
            'course_title',
            'enrolled_at',
            'source'
        )
        read_only_fields = fields

    def get_student_name(self, obj):
        if obj.user.first_name or obj.user.last_name:
            return f"{obj.user.first_name} {obj.user.last_name}".strip()
        return obj.user.username

    def get_source(self, obj):
        from orders.models import Purchase
        if Purchase.objects.filter(user=obj.user, course=obj.course, status='SUCCESS').exists():
            return 'Paid'
        return 'Manual / Free'


class LessonProgressSerializer(serializers.ModelSerializer):
    progress_percentage = serializers.ReadOnlyField()

    class Meta:
        model = LessonProgress
        fields = [
            'id',
            'lesson',
            'last_watched_position',
            'video_duration',
            'progress_percentage',
            'completed',
            'updated_at',
            'completed_at'
        ]
        read_only_fields = ['id', 'lesson', 'progress_percentage', 'updated_at', 'completed_at']


class LiveClassSerializer(serializers.ModelSerializer):
    course = serializers.PrimaryKeyRelatedField(queryset=Course.objects.all(), required=False)
    instructor = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=False, allow_null=True)

    class Meta:
        model = LiveClass
        fields = [
            'id',
            'batch',
            'course',
            'instructor',
            'title',
            'description',
            'scheduled_start',
            'duration_minutes',
            'meeting_provider',
            'meeting_url',
            'host_url',
            'status',
            'cancellation_reason',
            'recording_url',
            'recording_uploaded_at',
            'recurrence_rule',
            'created_at',
            'updated_at'
        ]
        read_only_fields = ['id', 'cancellation_reason', 'recording_uploaded_at', 'recurrence_rule', 'created_at', 'updated_at']

    def validate(self, attrs):
        import django.core.exceptions
        from django.utils import timezone
        from django.db.models import Q

        batch = attrs.get('batch')
        if not batch:
            if self.instance:
                batch = self.instance.batch

        # Validate that batch is required for new creation
        if not self.instance and not batch:
            raise serializers.ValidationError({"batch": "batch is required for new LiveClass creation."})

        if batch:
            # Promote batch.course to LIVE if not already
            if batch.course.course_type != 'LIVE':
                batch.course.course_type = Course.CourseType.LIVE
                batch.course.save(update_fields=['course_type'])

            # Verify batch has a valid instructor
            if not batch.instructor:
                raise serializers.ValidationError({"batch": "The batch must have an assigned instructor."})

            # Check for conflicting course/instructor values if provided in request.data
            request = self.context.get('request')
            if request and request.data:
                client_course = request.data.get('course')
                if client_course is not None and int(client_course) != batch.course.id:
                    raise serializers.ValidationError({"course": "Derived course and batch course do not match."})

                client_instructor = request.data.get('instructor')
                if client_instructor is not None and int(client_instructor) != batch.instructor.id:
                    raise serializers.ValidationError({"instructor": "Derived instructor and batch instructor do not match."})

            # If a teacher or mentor is creating/updating, verify they are
            # the instructor of the batch. Phase 2 fix: this previously only
            # checked is_teacher, so a mentor (who passes the view-level
            # has_permission check) could create a class under a batch they
            # don't actually own -- has_object_permission never runs for a
            # brand-new object on POST, so this serializer check was the
            # only real gate for mentors.
            user = self.context['request'].user
            if (getattr(user, 'is_teacher', False) or getattr(user, 'is_mentor', False)) and not (user.is_superuser or user.is_staff):
                if batch.instructor != user:
                    raise serializers.ValidationError({"batch": "Teachers/mentors can only create/update sessions for their own batches."})

        duration_minutes = attrs.get('duration_minutes')
        if duration_minutes is None and self.instance:
            duration_minutes = self.instance.duration_minutes

        if duration_minutes is not None and duration_minutes <= 0:
            raise serializers.ValidationError({"duration_minutes": "Duration must be greater than 0."})

        # Phase D: Scheduling Conflict Detection
        scheduled_start = attrs.get('scheduled_start')
        if not scheduled_start and self.instance:
            scheduled_start = self.instance.scheduled_start

        if scheduled_start and duration_minutes:
            # 1. Past check (only when creating or modifying scheduled_start)
            if 'scheduled_start' in attrs and scheduled_start < timezone.now():
                raise serializers.ValidationError({"scheduled_start": ["Live classes cannot be scheduled in the past."]})

            # 2. Conflict check
            end = scheduled_start + timezone.timedelta(minutes=duration_minutes)

            instructor = attrs.get('instructor')
            if not instructor and self.instance:
                instructor = self.instance.instructor
            if not instructor and batch:
                instructor = batch.instructor

            # Query relevant active sessions within a 24-hour bounding box for efficiency
            qs = LiveClass.objects.filter(status__in=[LiveClass.ClassStatus.SCHEDULED, LiveClass.ClassStatus.LIVE])
            if self.instance:
                qs = qs.exclude(pk=self.instance.pk)

            min_start = scheduled_start - timezone.timedelta(hours=24)
            max_start = end

            potential_conflicts = qs.filter(
                scheduled_start__lt=max_start,
                scheduled_start__gte=min_start
            ).filter(Q(batch=batch) | Q(instructor=instructor))

            for pc in potential_conflicts:
                pc_end = pc.scheduled_start + timezone.timedelta(minutes=pc.duration_minutes)
                if pc.scheduled_start < end and pc_end > scheduled_start:
                    if batch and pc.batch_id == batch.id:
                        raise serializers.ValidationError({"scheduled_start": ["This batch already has another live class scheduled during this time."]})
                    if instructor and pc.instructor_id == instructor.id:
                        raise serializers.ValidationError({"scheduled_start": ["This instructor already has another live class scheduled during this time."]})

            # 3. Availability check (Phase 2) -- opt-in: only enforced if the
            # instructor has defined TeacherAvailability windows at all, so
            # this never restricts scheduling for an instructor who hasn't
            # configured availability (backward compatible).
            if instructor:
                from .models import TeacherAvailability
                windows = TeacherAvailability.objects.filter(user=instructor, is_active=True)
                if windows.exists():
                    weekday = scheduled_start.weekday()
                    local_start = timezone.localtime(scheduled_start).time()
                    local_end = timezone.localtime(end).time()
                    day_windows = windows.filter(day_of_week=weekday)
                    fits_a_window = any(
                        w.start_time <= local_start and local_end <= w.end_time and local_end > local_start
                        for w in day_windows
                    )
                    if not fits_a_window:
                        raise serializers.ValidationError({
                            "scheduled_start": ["This time falls outside the instructor's configured availability."]
                        })

        return attrs

    def create(self, validated_data):
        batch = validated_data.get('batch')
        if batch:
            validated_data['course'] = batch.course
            validated_data['instructor'] = batch.instructor
        return super().create(validated_data)

    def update(self, instance, validated_data):
        batch = validated_data.get('batch')
        if batch:
            validated_data['course'] = batch.course
            validated_data['instructor'] = batch.instructor
        return super().update(instance, validated_data)

    def to_representation(self, instance):
        ret = super().to_representation(instance)
        request = self.context.get('request')
        if request and request.user:
            user = request.user
            if user.is_superuser or user.is_staff:
                pass
            elif getattr(user, 'is_teacher', False) or getattr(user, 'is_mentor', False):
                # Phase 2 fix: this previously only checked is_teacher, so a
                # mentor conducting their own batch fell through to the
                # student branch below and had their own meeting_url hidden
                # (they're never a LiveBatchStudent on their own batch).
                # Teacher/mentor can see meeting_url only if they are the
                # batch instructor.
                if not instance.batch or instance.batch.instructor != user:
                    ret['meeting_url'] = None
            else:
                # Student can see meeting_url only if assigned to this batch
                if instance.batch:
                    from courses.models import LiveBatchStudent
                    is_assigned = LiveBatchStudent.objects.filter(batch=instance.batch, student=user).exists()
                    if not is_assigned:
                        ret['meeting_url'] = None
                else:
                    ret['meeting_url'] = None
        else:
            ret['meeting_url'] = None

        # Secure host_url: only superuser, staff, or the batch's instructor can see it
        can_host = False
        if request and request.user:
            user = request.user
            if user.is_superuser or user.is_staff:
                can_host = True
            elif getattr(user, 'is_teacher', False) or getattr(user, 'is_mentor', False):
                if instance.batch and instance.batch.instructor == user:
                    can_host = True
        if not can_host:
            ret.pop('host_url', None)

        # Nest the recurrence rule (instead of a bare id) so the frontend can
        # render a "recurring series" badge without an extra request per class.
        if instance.recurrence_rule_id:
            ret['recurrence_rule'] = RecurrenceRuleSerializer(instance.recurrence_rule).data

        # Enrich representation with course_title, batch_name, instructor_name, and attendance counts
        if instance.course:
            ret['course_title'] = instance.course.title
        elif instance.batch and instance.batch.course:
            ret['course_title'] = instance.batch.course.title
        else:
            ret['course_title'] = ""

        if instance.batch:
            b_type = instance.batch.get_batch_type_display() if hasattr(instance.batch, 'get_batch_type_display') else "Group"
            ret['batch_name'] = f"{b_type} Batch #{instance.batch.id}"
        else:
            ret['batch_name'] = ""

        if instance.instructor:
            ret['instructor_name'] = instance.instructor.get_full_name() or instance.instructor.username
        elif instance.batch and instance.batch.instructor:
            ret['instructor_name'] = instance.batch.instructor.get_full_name() or instance.batch.instructor.username
        else:
            ret['instructor_name'] = ""

        try:
            records = list(instance.attendance_records.all())
            total_recs = len(records)
            present_recs = sum(1 for r in records if r.status in ('PRESENT', 'LATE'))
            total_duration = sum(getattr(r, 'duration_minutes', 0) for r in records)
            batch_count = instance.batch.students.count() if instance.batch else 0
            ret['attendance_total_count'] = total_recs if total_recs > 0 else batch_count
            ret['attendance_present_count'] = present_recs
            ret['attendance_avg_duration'] = round(total_duration / present_recs) if present_recs > 0 else 0
        except Exception:
            ret['attendance_total_count'] = 0
            ret['attendance_present_count'] = 0
            ret['attendance_avg_duration'] = 0

        rec_url = ret.get('recording_url')
        if rec_url and 'amazonaws.com' in rec_url and '?' not in rec_url:
            try:
                from courses.services.recording import ZoomRecordingService
                presigned = ZoomRecordingService.generate_presigned_download_url(rec_url)
                if presigned:
                    ret['recording_url'] = presigned
            except Exception:
                pass

        return ret


class LiveBatchSerializer(serializers.ModelSerializer):
    student_count = serializers.IntegerField(read_only=True, default=0)
    course_title = serializers.CharField(source='course.title', read_only=True)
    instructor_username = serializers.CharField(source='instructor.username', read_only=True, allow_null=True)

    class Meta:
        model = LiveBatch
        fields = ['id', 'course', 'course_title', 'instructor', 'instructor_username', 'batch_type', 'max_participants', 'student_count', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        import django.core.exceptions

        # Phase 2: a non-admin teacher/mentor may only create/manage a batch
        # where THEY are the instructor -- has_object_permission never runs
        # for a brand-new object on POST, so this is the real gate for
        # "teachers/mentors can create their own sessions" without letting
        # one teacher create a batch on another's behalf.
        request = self.context.get('request')
        user = getattr(request, 'user', None)
        if user and not (user.is_superuser or user.is_staff):
            instructor = attrs.get('instructor')
            if instructor is None and not self.instance:
                attrs['instructor'] = user
            elif instructor is not None and instructor != user:
                raise serializers.ValidationError({"instructor": "You can only create/manage sessions for yourself."})
            elif self.instance and self.instance.instructor != user:
                raise serializers.ValidationError({"instructor": "You can only manage your own batches."})

        # Handle validation for both create and update instances
        instance = self.instance or LiveBatch()
        for field, value in attrs.items():
            setattr(instance, field, value)
        try:
            instance.clean()
        except django.core.exceptions.ValidationError as e:
            raise serializers.ValidationError(e.message_dict if hasattr(e, 'message_dict') else e.messages)
        return attrs


class LiveBatchStudentSerializer(serializers.ModelSerializer):
    student_username = serializers.CharField(source='student.username', read_only=True)
    purchase_status = serializers.CharField(source='purchase.status', read_only=True, allow_null=True)

    class Meta:
        model = LiveBatchStudent
        fields = ['id', 'batch', 'student', 'student_username', 'purchase', 'purchase_status', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']


from .models import RecurrenceRule, TeacherAvailability, Attendance


class RecurrenceRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecurrenceRule
        fields = ['id', 'frequency', 'weekdays', 'end_date', 'occurrence_count', 'created_by', 'created_at']
        read_only_fields = ['id', 'created_by', 'created_at']


class TeacherAvailabilitySerializer(serializers.ModelSerializer):
    day_of_week_display = serializers.CharField(source='get_day_of_week_display', read_only=True)
    # Explicitly required=False: the model FK itself is required (every row
    # must belong to someone), but a self-service teacher/mentor POST omits
    # `user` entirely and relies on validate()/perform_create() defaulting it
    # to the caller -- only an admin needs to pass it, to act on someone
    # else's behalf.
    user = serializers.PrimaryKeyRelatedField(queryset=User.objects.all(), required=False)

    class Meta:
        model = TeacherAvailability
        fields = ['id', 'user', 'day_of_week', 'day_of_week_display', 'start_time', 'end_time', 'is_active', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate(self, attrs):
        import django.core.exceptions

        request = self.context.get('request')
        acting_user = getattr(request, 'user', None)
        target_user = attrs.get('user') or getattr(self.instance, 'user', None) or acting_user
        if acting_user and not (acting_user.is_superuser or acting_user.is_staff) and target_user != acting_user:
            raise serializers.ValidationError({"user": "You can only manage your own availability."})

        instance = self.instance or TeacherAvailability(user=target_user)
        for field, value in attrs.items():
            setattr(instance, field, value)
        try:
            instance.clean()
        except django.core.exceptions.ValidationError as e:
            raise serializers.ValidationError(e.message_dict if hasattr(e, 'message_dict') else e.messages)
        return attrs


class AttendanceSerializer(serializers.ModelSerializer):
    student_name = serializers.SerializerMethodField()

    class Meta:
        model = Attendance
        fields = ['id', 'live_class', 'student', 'student_name', 'status', 'duration_minutes', 'joined_at', 'left_at', 'marked_by', 'marked_at', 'notes']
        read_only_fields = ['id', 'live_class', 'marked_by', 'marked_at', 'joined_at', 'left_at']

    def get_student_name(self, obj):
        name = f"{obj.student.first_name} {obj.student.last_name}".strip()
        return name or obj.student.username

    def validate_student(self, value):
        live_class = self.context.get('live_class')
        if live_class and live_class.batch:
            from .models import LiveBatchStudent
            if not LiveBatchStudent.objects.filter(batch=live_class.batch, student=value).exists():
                raise serializers.ValidationError("This student is not assigned to this class's batch.")
        return value


# =============================================================================
# Phase 4.2: learner-facing assessment serializers.
#
# Every serializer below is a deliberate field WHITELIST (explicit
# `fields = [...]`), never `fields = '__all__'` -- so a field added to
# Question/QuestionOption in a later phase can't leak to a learner just
# because nobody remembered to exclude it. is_correct never appears here.
# =============================================================================

class SafeQuestionOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionOption
        fields = ['id', 'option_text', 'order']


class SafeQuestionSerializer(serializers.ModelSerializer):
    options = SafeQuestionOptionSerializer(many=True, read_only=True)

    class Meta:
        model = Question
        fields = ['id', 'question_text', 'question_type', 'order', 'marks', 'is_required', 'options']


class SafeAssessmentSerializer(serializers.ModelSerializer):
    """Assessment metadata safe to show a student before/while attempting
    it -- passing_percentage/max_attempts/time_limit_minutes are the
    syllabus, not the answer key, so they're fine to expose."""
    class Meta:
        model = Assessment
        fields = ['id', 'title', 'description', 'instructions', 'passing_percentage', 'max_attempts', 'time_limit_minutes']


class AssessmentAttemptListSerializer(serializers.ModelSerializer):
    """For GET /assessment-attempts/my/ -- attempt history, no question data."""
    assessment_id = serializers.IntegerField(source='assessment.id', read_only=True)
    assessment_title = serializers.CharField(source='assessment.title', read_only=True)
    can_review = serializers.SerializerMethodField()

    class Meta:
        model = AssessmentAttempt
        fields = [
            'id', 'assessment_id', 'assessment_title', 'attempt_number', 'status',
            'started_at', 'submitted_at', 'score', 'percentage', 'passed', 'can_review',
        ]

    def get_can_review(self, obj):
        # Phase 4.4: matches _serialize_finished_attempt's own gate in
        # courses/views.py -- a SUBMITTED or TIMED_OUT attempt can be
        # reviewed (GET .../<id>/ already returns the review payload for
        # both), an IN_PROGRESS one cannot.
        return obj.status in (AssessmentAttempt.Status.SUBMITTED, AssessmentAttempt.Status.TIMED_OUT)


class ReviewQuestionOptionSerializer(serializers.ModelSerializer):
    """
    Phase 4.4 CORRECTION. ONLY ever used for a SUBMITTED attempt's review
    (never for an IN_PROGRESS one -- SafeQuestionOptionSerializer, which
    has no correctness field at all, is used there). Built over
    AssessmentAnswerOptionSnapshot, NOT the live QuestionOption --
    `option_text`/`order` are this snapshot row's own frozen columns
    (copied from the option at submission time, so a later edit to
    QuestionOption.option_text can't change what a student's historical
    review shows), and `is_correct_answer` is sourced from the snapshot's
    frozen `was_correct`, never from live QuestionOption.is_correct. `id`
    is the underlying option's real id (via `option_id`) purely so the
    frontend can match this row against `selected_option_ids` -- no other
    field here is ever read from the live `option` relation.
    """
    id = serializers.IntegerField(source='option_id', read_only=True)
    is_correct_answer = serializers.BooleanField(source='was_correct', read_only=True)

    class Meta:
        model = AssessmentAnswerOptionSnapshot
        fields = ['id', 'option_text', 'order', 'is_correct_answer']


class CertificateSerializer(serializers.ModelSerializer):
    """
    Phase 4.6. Owner-facing -- returned only from endpoints already
    scoped to `student=request.user` (see CertificateViewSet). Explicit
    whitelist, matching every other learner-facing serializer in this
    module: course_id/course_title are included for convenience (avoids
    a second round-trip to resolve which course this certificate is
    for), but nothing assessment-derived (no score/marks/percentage --
    Phase 4.6 Section 6 explicitly prohibits inventing those on a
    certificate) is ever included here.
    """
    course_id = serializers.IntegerField(source='course.id', read_only=True)

    class Meta:
        model = Certificate
        fields = [
            'id', 'course_id', 'verification_id',
            'learner_name_snapshot', 'course_title_snapshot', 'issued_at',
        ]
        read_only_fields = fields


class AdminCertificateSerializer(CertificateSerializer):
    """
    Admin Dashboard Completion gap fix. CertificateViewSet has no
    admin-wide list/retrieve (every action is hard-scoped to
    student=request.user) -- this is the admin-facing surface, mirroring
    finance/serializers.py's AdminInvoiceSerializer(MyInvoiceSerializer)
    exact shape: extends the owner-facing serializer unchanged, adding
    only WHOSE certificate this is (the entire point of admin
    inspection), still nothing assessment-derived.
    """
    student = serializers.SerializerMethodField()

    class Meta(CertificateSerializer.Meta):
        fields = CertificateSerializer.Meta.fields + ['student']
        read_only_fields = fields

    def get_student(self, obj):
        return {'id': obj.student_id, 'username': obj.student.username}


class PublicCertificateVerificationSerializer(serializers.ModelSerializer):
    """
    Phase 4.6. The PUBLIC, unauthenticated verification response --
    deliberately a much narrower whitelist than CertificateSerializer:
    no `id` (the internal DB pk), no `course_id`, no way to reach the
    owning student's account at all. Only what's needed to establish
    "yes, this is a real, valid certificate, issued to this name for
    this course, on this date" -- exactly Phase 4.6 Section 9's list,
    nothing more.
    """
    class Meta:
        model = Certificate
        fields = ['verification_id', 'learner_name_snapshot', 'course_title_snapshot', 'issued_at']
        read_only_fields = fields


class CertificateTemplateSerializer(serializers.ModelSerializer):
    course_title = serializers.CharField(source='course.title', read_only=True)

    class Meta:
        model = CertificateTemplate
        fields = [
            'id', 'course', 'course_title', 'title', 'institute_name', 'institute_tagline',
            'presentation_line', 'description_text', 'theme', 'border_style',
            'signatory1_name', 'signatory1_title', 'signatory1_signature', 'signatory1_font',
            'signatory2_name', 'signatory2_title', 'signatory2_signature', 'signatory2_font',
            'logo_url', 'logo_size', 'secondary_logo_url', 'secondary_logo_size',
            'watermark_url', 'watermark_opacity',
            'seal_type', 'seal_url', 'seal_text',
            'name_font_style', 'title_font_size', 'custom_gold_color',
            'show_qr', 'show_verification_id', 'show_issue_date',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']



# =============================================================================
# Phase 4.7: Assignments & Grading.
# =============================================================================

def _serialize_assignment_summary_for_student(assignment, submissions):
    """
    Mirrors _serialize_assessment_summary_for_student's exact shape and
    reasoning: a safe per-assignment summary derived only from THIS
    student's own submissions (already scoped to student=request.user by
    the caller -- see CourseViewSet.get_serializer_context), one query
    total for the whole request. `submissions` is this student's own
    AssignmentSubmission rows for this assignment, any order.
    """
    latest = max(submissions, key=lambda s: s.attempt_number) if submissions else None
    return {
        "id": assignment.id,
        "title": assignment.title,
        "max_marks": assignment.max_marks,
        "status": latest.status if latest else "NOT_SUBMITTED",
        "attempt_number": latest.attempt_number if latest else None,
        "submission_id": latest.id if latest else None,
        "marks_awarded": latest.marks_awarded if latest else None,
        "feedback": latest.feedback if (latest and latest.status != AssignmentSubmission.Status.SUBMITTED) else "",
    }


class AssignmentSerializer(serializers.ModelSerializer):
    """Safe fields only -- used for the learner-facing detail/submit
    screen. Matches SafeAssessmentSerializer's exact whitelist philosophy."""
    class Meta:
        model = Assignment
        fields = ['id', 'title', 'description', 'max_marks', 'order']
        read_only_fields = fields


class AdminAssignmentSerializer(serializers.ModelSerializer):
    """
    Admin Dashboard Completion gap fix. AssignmentViewSet has no
    list/create/update/destroy at all (student-facing retrieve/submit
    only, per this model's own established design -- authoring stays
    Django-admin-only, mirroring Assessment) -- there was no way for an
    admin/teacher to see "every assignment across every course" or spot
    which ones have ungraded submissions waiting, without already
    knowing a specific assignment_id to query AssignmentSubmissionViewSet.
    by_assignment. This is purely a read-only aggregate view over
    already-existing data -- course/module context plus a submission
    count annotated in the view's queryset (never computed here), no new
    grading logic, no change to how grading itself works.
    """
    course_id = serializers.IntegerField(source='module.course.id', read_only=True)
    course_title = serializers.CharField(source='module.course.title', read_only=True)
    module_id = serializers.IntegerField(source='module.id', read_only=True)
    module_title = serializers.CharField(source='module.title', read_only=True)
    pending_submission_count = serializers.IntegerField(read_only=True)

    class Meta:
        model = Assignment
        fields = [
            'id', 'title', 'course_id', 'course_title', 'module_id', 'module_title',
            'max_marks', 'order', 'is_published', 'pending_submission_count',
        ]
        read_only_fields = fields


class AssignmentSubmissionSerializer(serializers.ModelSerializer):
    """
    Used for both the student's own view of their submission(s) and the
    teacher/admin grading queue -- exposing the student's own name/email
    back to themselves is not a security concern (CourseInstructorSerializer's
    get_user_name is the exact same pattern), and a teacher legitimately
    needs to know WHOSE submission they're grading. Ownership/authorization
    itself is enforced entirely at the view/queryset layer, never here.
    """
    student_name = serializers.SerializerMethodField()
    student_email = serializers.EmailField(source='student.email', read_only=True)
    assignment_title = serializers.CharField(source='assignment.title', read_only=True)
    max_marks = serializers.DecimalField(source='assignment.max_marks', max_digits=6, decimal_places=2, read_only=True)

    class Meta:
        model = AssignmentSubmission
        fields = [
            'id', 'assignment', 'assignment_title', 'max_marks',
            'student', 'student_name', 'student_email',
            'attempt_number', 'status', 'content', 'submitted_file',
            'marks_awarded', 'feedback', 'graded_by', 'graded_at',
            'submitted_at', 'updated_at',
        ]
        read_only_fields = fields

    def get_student_name(self, obj):
        name = f"{obj.student.first_name} {obj.student.last_name}".strip()
        return name or obj.student.username
