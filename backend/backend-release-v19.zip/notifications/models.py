from django.db import models
from users.models import User
from courses.models import Course

class NotificationType(models.TextChoices):
    COURSE_UPDATE = 'COURSE_UPDATE', 'Course Update'
    ENROLLMENT = 'ENROLLMENT', 'Enrollment'
    PAYMENT = 'PAYMENT', 'Payment'
    ANNOUNCEMENT = 'ANNOUNCEMENT', 'Announcement'
    COURSE_COMPLETION = 'COURSE_COMPLETION', 'Course Completion'
    CERTIFICATE = 'CERTIFICATE', 'Certificate'
    LIVE_CLASS = 'LIVE_CLASS', 'Live Class'
    ASSIGNMENT = 'ASSIGNMENT', 'Assignment'

class Notification(models.Model):
    recipient = models.ForeignKey(
        User,
        related_name="notifications",
        on_delete=models.CASCADE,
        db_index=True
    )
    title = models.CharField(max_length=255)
    body = models.TextField()
    notification_type = models.CharField(
        max_length=50,
        choices=NotificationType.choices,
        default=NotificationType.ANNOUNCEMENT
    )
    is_read = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    read_at = models.DateTimeField(null=True, blank=True)
    action_url = models.CharField(max_length=500, blank=True)
    idempotency_key = models.CharField(
        max_length=255,
        unique=True,
        null=True,
        blank=True,
        db_index=True,
    )

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.recipient.username} - {self.title} ({self.get_notification_type_display()})"


class DeviceToken(models.Model):
    """
    Phase 4.10: minimum viable groundwork for push notifications --
    REGISTRATION ONLY. Deliberately does NOT wire any actual push
    delivery (an Expo push API call) into NotificationService.create_notification
    yet -- that function is the single most reused call path in this app
    (orders/finance/courses/users all call it), and threading a network
    call plus per-token error/expiry handling through it safely is a
    separate, larger, more carefully-tested phase of its own, not a
    "small, safe" addition. This model + DeviceTokenView exist so that
    phase, whenever it happens, has real, already-collected tokens to
    send to. Nothing about the existing in-app Notification/
    NotificationViewSet list/read/read-all behavior is touched by this.

    `token` (not `user`) is the unique key: the same physical device's
    Expo push token can legitimately move to a different user (logout,
    different student logs in on the same device) -- re-registering that
    token reassigns ownership via update_or_create rather than creating
    an orphaned second row for the old user.
    """
    class Platform(models.TextChoices):
        IOS = 'IOS', 'iOS'
        ANDROID = 'ANDROID', 'Android'

    user = models.ForeignKey(User, related_name='device_tokens', on_delete=models.CASCADE)
    token = models.CharField(max_length=255, unique=True, db_index=True)
    platform = models.CharField(max_length=10, choices=Platform.choices)
    is_active = models.BooleanField(default=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"{self.user.username} - {self.platform} - {self.token[:24]}..."


class Announcement(models.Model):
    sender = models.ForeignKey(
        User,
        related_name="announcements",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    course = models.ForeignKey(
        Course,
        related_name="announcements",
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    title = models.CharField(max_length=255)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_published = models.BooleanField(default=False)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
